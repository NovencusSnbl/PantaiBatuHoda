<?php
  require_once 'functions.php';

  $room = query("SELECT  * FROM categori");
  $waha = query("SELECT * FROM wahana");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  <title>Pantai HD</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">  
  <link rel="stylesheet" type="text/css" href="css/styleMap.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/wahana.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>
<?php
	include 'header.php';
?>
<br><hr><br><hr>

<body>
	<div class="container-fluid">
		<div>
		  <b><u><p id="tentang" class="text-center" style="font-size: 33px; margin-top: 16px">Wahana Air</p></u></b>
		</div>

		<br>
		<div class="row">
			<div class="col-md-6">
				<img id="waha" src="images/banana.jpg">
			</div>
			<div class="col-md-6">
				<h4>Banana Boat</h4>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<h4>Kano</h4>
			</div>
			<div class="col-md-6">
				<img id="waha" src="images/kano.jpg">
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<img id="waha" src="images/sepeda.jpg">
			</div>
			<div class="col-md-6">
				<h4>Sepeda Air</h4>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<h4>Ban Air</h4>
			</div>
			<div class="col-md-6">
				<img id="waha" src="images/ban.jpg">
			</div>
		</div>
	</div>
</body>

<br><hr>
<?php
	include 'footer.php';
?>
