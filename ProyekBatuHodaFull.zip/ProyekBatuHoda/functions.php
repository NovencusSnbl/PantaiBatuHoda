<?php
$conn=mysqli_connect("localhost","root","","batuhodadb");


function query($query ){
	global $conn;  
	$result = mysqli_query($conn,$query);
	$rows=[];
	while 	($row = mysqli_fetch_assoc($result)) {
		$rows[]=$row;
	}
	return $rows;
}

function coba1($id){
	if($id == 1){
		return "Standard Room";
	}else if($id == 2){
		return "Family Room";
	}else if($id == 3){
		return "Villa";
	}
}
function pesann($pesan){
	global $conn;  
	$id_homestay=htmlspecialchars($pesan["id_homestay"]);
	$checkin=htmlspecialchars($pesan["checkin"]);
	 $checkout=htmlspecialchars($pesan["checkout"]);
	 $tglcheckin = date('Y-m-d',strtotime($checkin));
	 $tglcheckout = date('Y-m-d',strtotime($checkout));
	 $name=htmlspecialchars($pesan["name"]);
	 $nomor=htmlspecialchars($pesan["nomor"]);
	 $email=htmlspecialchars($pesan["email"]);
	 $room=htmlspecialchars($pesan["room"]);
	 hp($nomor);
	 $isValidEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
			if ($isValidEmail===false) {
			echo "<script>
				alert('Tiket gagal dipesan, penggunaan email tidak valid :)');
				document.location.href = 'index.php'
				</script>";
			}
			else{

	 $query="INSERT INTO booking VALUES('',$id_homestay,'$tglcheckin','$tglcheckout','$email','$nomor','$room')";
	 if (mysqli_query($conn,$query)) {
					$id = $conn->insert_id;
					require 'PHPMailer/PHPMailerAutoload.php';

					$query = "SELECT * FROM booking WHERE idbooking=$id LIMIT 1";

			        $result = mysqli_query($conn, $query);
			        $row = mysqli_fetch_array($result);
					$mail = new PHPMailer;

					//$mail->SMTPDebug = 3;                               // Enable verbose debug output

					$mail->isSMTP();                                      // Set mailer to use SMTP
					$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
					$mail->SMTPAuth = true;                               // Enable SMTP authentication
					$mail->Username = 'nvsgokilabis@gmail.com';                 // SMTP username
					$mail->Password = '20001107n';                           // SMTP password
					$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
					$mail->Port = 465;                                    // TCP port to connect to

					$mail->setFrom('nvsgokilabis@gmail.com', 'Amaris Homestay');
					$mail->addAddress($pesan["email"], 'USER');     // Add a recipient
					//$mail->addAddress('ellen@example.com');               // Name is optional
					$mail->addReplyTo('nestatbn28@gmail.com', 'Information');
					$mail->addCC('nestatbn28@gmail.com');
					$mail->addBCC('bcc@example.com');

					$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
					$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
					$mail->isHTML(true);                                  // Set email format to HTML

					$mail->Subject = 'Pemeberitahuan Pembookingan';
					$mail->Body    = $row['gmail'].' berhasil memesan Room.'.'
						<div class="container form-register">
						<fieldset >
							<div class="form-group">
								<label class="col-sm-4 control-label">Kategori Room</label>
								<label class="col-sm-4 control-label">    :'.coba1($row["id_homestay"]).'</label>
							</div>

							<div class="form-group">
								<label class="col-sm-4 control-label">Checkin</label>
								<label class="col-sm-4 control-label">    :'.$row["checkin"].'</label>
							</div>


							<div class="form-group">
								<label class="col-sm-4 control-label">Checkout</label>
								<label class="col-sm-2 control-label">    :'.$row["checkout"].'</label>
							</div>

							<div class="form-group">
								<label class="col-sm-4 control-label">No.Telepon</label>
								<label class="col-sm-4 control-label">    :'.$row["notelp"].'</label>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label">Jumlah Tamu</label>
								<label class="col-sm-3 control-label">    :'.$row["jlh_orang"].'</label>
							</div>
							
						</fieldset>
				</div>
					';
					$mail->AltBody = 'Selamat berlibur :)';
					if(!$mail->send()) {
					    echo 'Message could not be sent.';
					    echo 'Mailer Error: ' . $mail->ErrorInfo;
					} else {
					    echo 'Message has been sent';
						echo "<script>
						alert('Room Berhasil dipesan, silahkan cek email anda :)');
						document.location.href = 'detail_booking.php?id=" . $id . "'
						</script>";
					}
				}
			}
		}	
function hp($nohp)
{
 $nohp = str_replace(" ","",$nohp);
 // kadang ada penulisan no hp 0811 239 345
 $nohp = str_replace("(","",$nohp);
 // kadang ada penulisan no hp (0274) 778787
 $nohp = str_replace(")","",$nohp);
 // kadang ada penulisan no hp (0274) 778787
 $nohp = str_replace(".","",$nohp);
 // kadang ada penulisan no hp 0811.239.345 

 if(!preg_match('/[^+0-9]/',trim($nohp)))
 // cek apakah no hp mengandung karakter + dan 0-9
 {
	 if ($nohp[0] == '0') {
	 	if(substr(trim($nohp), 0, 3)=='+62')
		 // cek apakah no hp karakter 1-3 adalah +62
		 {
		 	$hp = trim($nohp);
		 }
		 elseif(substr(trim($nohp), 0, 1)=='0')
		 // cek apakah no hp karakter 1 adalah 0
		 {
		 	$hp = '+62'.substr(trim($nohp), 1);
		 }
		 if (strlen($nohp) < 10) {
		 	$hp = 'Format no hp yang dimasukkan tidak lengkap atau salah!(Indonesia)';
			echo "<script>
			alert('$hp');
			document.location.href = 'index.php'
			</script>"; 	
			exit();
		 }
	 }else if($nohp[0] == '+'){
	 	if(substr(trim($nohp), 0, 3)=='+62')
		 // cek apakah no hp karakter 1-3 adalah +62
		 {
		 	$hp = trim($nohp);
		 }
		 elseif(substr(trim($nohp), 0, 1)=='0')
		 // cek apakah no hp karakter 1 adalah 0
		 {
		 	$hp = '+62'.substr(trim($nohp), 1);
		 }
		 if (strlen($nohp) < 12) {
		 	$hp = 'Format no hp yang dimasukkan minimal 12 karakter!';
			echo "<script>
			alert('$hp');
			document.location.href = 'index.php'
			</script>"; 	
			exit();
		 }
	 }
	 else{
		$hp = 'Format no hp yang dimasukkan tidak lengkap atau salah!(Indonesia)';
		echo "<script>
		alert('$hp');
		document.location.href = 'index.php'
		</script>"; 	
		exit();
	 }
	 // fungsi trim() untuk menghilangan
	 // spasi yang ada didepan/belakang
 }
 else
 {
 	$hp = 'Format no hp yang dimasukkan tidak lengkap atau salah!(Indonesia)';
 	echo "<script>
		alert('$hp');
		document.location.href = 'index.php'
		</script>";
		exit(); 	
 }
}

function tiket($data){
	//ambil data dari tiap elemen
	global $conn;	

	 date_default_timezone_set('Asia/Jakarta');
	  // Hasil: 20-01-2017 05:32:15
	 $tanggal=htmlspecialchars($data["tanggal"]);
	 $nama=htmlspecialchars($data["nama"]);
	 $tglpesan = date('Y-m-d',strtotime($tanggal));
	 $email=htmlspecialchars($data["email"]);
	 $jumlah=$data["jumlah"];	
	 $telpon=htmlspecialchars($data["telpon"]);
	 $harga = $jumlah * 14000;
	 hp($telpon);	
			
	$awal  = strtotime(date('Y-m-d'));
	$akhir = time(); // Waktu sekarang
	$diff  = $akhir - $awal;
	$hari  = ceil($diff / (60 * 60 * 24));
	$now = date('Y-m-d');

	// $total="SELECT SUM(jlh_pesan) as jumlah_tiket FROM tiket WHERE tanggal_kunjungan = $tglpesan";

	$sqlChecktiket = "SELECT SUM(jlh_pesan) as jumlah_tiket FROM tiket WHERE tanggal_kunjungan = '$tglpesan'";

			$tiketQuery = mysqli_query($conn,$sqlChecktiket); 
			$blas = mysqli_fetch_assoc($tiketQuery);
			$jumlah_tiket = $blas['jumlah_tiket'];
			$sisa = 200 - $jumlah_tiket;
			$cukup = $sisa - $jumlah;
			
			$isValidEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
			if ($isValidEmail===false) {
			echo "<script>
				alert('Tiket gagal dipesan, penggunaan email tidak valid :)');
				document.location.href = 'index.php'
				</script>";
			}
			else{
			if (mysqli_num_rows($tiketQuery) > 0 && $cukup >= 0) {
				$sql_pesan = "INSERT INTO tiket VALUES('','$tglpesan','$nama','$email','$jumlah','$telpon','$harga')";

				if (mysqli_query($conn,$sql_pesan)) {
					$id = $conn->insert_id;
					require 'PHPMailer/PHPMailerAutoload.php';

					$query = "SELECT * FROM tiket WHERE id_tiket=$id LIMIT 1";

			        $result = mysqli_query($conn, $query);
			        $row = mysqli_fetch_array($result);
					$mail = new PHPMailer;

					//$mail->SMTPDebug = 3;                               // Enable verbose debug output

					$mail->isSMTP();                                      // Set mailer to use SMTP
					$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
					$mail->SMTPAuth = true;                               // Enable SMTP authentication
					$mail->Username = 'nvsgokilabis@gmail.com';                 // SMTP username
					$mail->Password = '20001107n';                           // SMTP password
					$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
					$mail->Port = 465;                                    // TCP port to connect to

					$mail->setFrom('nvsgokilabis@gmail.com', 'Amaris Homestay');
					$mail->addAddress($row['email'], 'USER');     // Add a recipient
					//$mail->addAddress('ellen@example.com');               // Name is optional
					$mail->addReplyTo('nestatbn28@gmail.com', 'Information');
					$mail->addCC('nestatbn28@gmail.com');
					$mail->addBCC('bcc@example.com');

					$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
					$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
					$mail->isHTML(true);                                  // Set email format to HTML

					$mail->Subject = 'Pemeberitahuan Pemesanan';
					$mail->Body    = $row['email'].' berhasil memesan tiket.'.'
						<div class="container form-register">
						<fieldset >
							
							<div class="form-group">
								<label class="col-sm-4 control-label">Nama</label>
								<label class="col-sm-4 control-label">    :'.$row["nama"].'</label>
							</div>

							<div class="form-group">
								<label class="col-sm-4 control-label">No.Telepon</label>
								<label class="col-sm-4 control-label">    :'.$row["no_telp"].'</label>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label">Guest</label>
								<label class="col-sm-2 control-label">    :'.$row["jlh_pesan"].'</label>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label">Tanggal Pemesanan</label>
								<label class="col-sm-3 control-label">    :'.$row["tanggal_kunjungan"].'</label>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Total</label>
								<label class="col-sm-6 control-label" style="font-size:20px;color:green;">    :'.$row["harga"].'</label>
							</div>
							
						</fieldset>
				</div>
					';
					$mail->AltBody = 'Selamat berlibur :)';
					if(!$mail->send()) {
					    echo 'Message could not be sent.';
					    echo 'Mailer Error: ' . $mail->ErrorInfo;
					} else {
					    echo 'Message has been sent';
						echo "<script>
						alert('Tiket Berhasil dipesan, silahkan cek email anda :)');
						document.location.href = 'detail_tiket.php?id=" . $id . "'
						</script>";
					}
				}
			}
			else
			{
				echo "<script>
				alert('Tiket gagal dipesan, sudah memnuhi kuota :)');
				document.location.href = 'index.php'
				</script>";
			}
		}	
}
	
?>