<!-- Nama : Kevin Aruan   
NIM : 11418051 
Kelas : 41TI2  
-->
<?php
require_once 'functions.php';
//pagination
//konfigurasi
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tiket</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/myStyle1.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/register.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrapvalidator.min.js"></script>
	<script src="js/js.js"></script>
	<script src="jquery-ui.js"></script>
	 <script> 


  </script>
</head>
<body>
	<?php
		if (isset($_GET['id'])) {
			$id = $_GET['id'];
		}
		$sql = "SELECT * FROM tiket WHERE id_tiket = '$id'";
	
	//Mendapatkan Hasil 
		$r = mysqli_query($conn,$sql);
		
		//Memasukkan Hasil Kedalam Array
		$result = array();
		$row = mysqli_fetch_array($r);
		
		array_push($result,array(
				"tanggal_kunjungan"=>$row['tanggal_kunjungan'],
				"nama"=>$row['nama'],
				"email"=>$row['email'],
				"jlh_pesan"=>$row['jlh_pesan'],
				"no_telp"=>$row['no_telp'],
				"harga"=>$row['harga']
			));

	?>
	<div class="container form-register">
			<fieldset >
				<center><img width="150" height="120" src="images/Logo1.png"><font color="#F55400">Ticket Information</font></center></legend>
	
				<div class="form-group">
					<label class="col-sm-4 control-label">Nama</label>
					<label class="col-sm-4 control-label"><?php echo $row["nama"] ?></label>
				</div>

				<div class="form-group">
					<label class="col-sm-4 control-label">Email</label>
					<label class="col-sm-4 control-label"><?php echo $row["email"] ?></label>

				</div>

				<div class="form-group">
					<label class="col-sm-4 control-label">No.Telepon</label>
					<label class="col-sm-4 control-label"><?php echo $row["no_telp"] ?></label>
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Guest</label>
					<label class="col-sm-2 control-label"><?php echo $row["jlh_pesan"] ?></label>
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Tanggal Pemesanan</label>
					<label class="col-sm-3 control-label"><?php echo $row["tanggal_kunjungan"] ?></label>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Total</label>
					<label class="col-sm-6 control-label" style="margin-left: 90px"><?php echo "Rp.".$row["harga"] ?></label>
				</div>
				<div class="form-group"><button type="submit" class="btn btn-warning btn-secondary btn-block" onclick="window.open('index.php')">Home</button>
			</fieldset>
	</div>
	
</body>
</html>