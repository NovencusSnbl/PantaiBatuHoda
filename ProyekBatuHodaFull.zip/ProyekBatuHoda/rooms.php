<?php
require 'functions.php';
if (isset($_GET['idkategori'])) {
            $id = $_GET['idkategori'];
        }
$room = mysqli_query($conn,"SELECT * FROM categori inner join homestay on homestay.id_categori=categori.id_categori WHERE categori.id_categori=$id");
if(isset($_POST["pesann"])) {

               //cek apakah data berhasil dikirm atau tidak
                pesann($_POST);}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Hotel Template">
    <meta name="keywords" content="Hotel, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HomeStay</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">  
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link href="css/css.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:9999;width: 100%">  
    <a href="index.php"><img src="img/Logo1.png" class="navbar-brand" style="height: 65px; width: 125px;"></img></a>
 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
 
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
 
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#tentang">Tentang</a>
        </li>   
         <li class="nav-item">
          <a class="nav-link" href="#fasilitas">Fasilitas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Hubungi Kami</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"> </a>
        </li>
        
      </ul>
    </div>
</nav>
    <!-- Page Preloder -->
    <!-- <div id="preloder">
        <div class="loader"></div>
    </div> -->

    <!-- Header Section Begin -->
    
    <!-- Header End -->

    <!-- Hero Area Section Begin -->
  <!-- 
    <div class="hero-area "> -->
        
    <!-- /</div> -->
    <!-- Hero Area Section End -->

    <!-- Search Filter Section Begin -->
    
    <!-- Search Filter Section End -->

    <!-- Room Section Begin -->

 
           
        
        <?php  while($row=mysqli_fetch_array($room)) {?>
           <div class="container-fluid" style="margin-left: 20px">
            <div class="row">
                <div class="col-lg-6">
                    <div class="ri-slider-item">
                            <img src="img/rooms/<?php echo $row["foto"] ?>" style="width: 60%;height: 360px;margin-left: 80px">
                    </div>
                </div>
                <div class="col-lg-6" style="margin-top: -180px;margin-left: -100px">
                    <div class="ri-text">
                        <div class="section-title">
                            <div class="section-title">
                                <span><?php if($row["id_categori"] == 1){
                                    echo "Standard Room";
                                }elseif ($row["id_categori"] == 2) {
                                    echo "Family Room";
                                }else{
                                    echo "Villa";
                                } ?></span>
                                <h2 style="font-size: 20px"><?php echo $row["harga"] ?></h2>
                            </div>
                            <p style="font-size: 12px;margin-top: -20px"><?php echo $row["deskripsi"] ?></p>
                            <div class="ri-features" style="margin-top: -20px">
                                <div class="ri-info">
                                    <i class="flaticon-019-television"></i>
                                    <p style="font-size: 9px">Smart TV</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-029-wifi"></i>
                                    <p style="font-size: 9px">High Wi-fii</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-003-air-conditioner"></i>
                                    <p style="font-size: 9px">AC</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-036-parking" ></i>
                                    <p style="font-size: 9px">Parking</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-007-swimming-pool"></i>
                                    <p style="font-size: 9px">Pool</p>
                                </div>

                            <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;margin-top: -2px">Pesan</button>
                            </div>


                            <div id="id01" class="modal">
                              
                                <form class="modal-content animate" action=" " method="post">
                                        <input type="hidden" name="id_homestay" value="<?php echo $id?>">
                                  <div class="imgcontainer">
                                    <h2>Booking Kapasitas kamar</h2>
                                    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal" >&times;</span>
                                  </div>
                                  <div class="container" style="width: 95%">
                                  <div class="form-row align-items-center">
                                    <div class="col-sm-6 my-2">
                                      <label>Check In</label>
                                      <input type="text" class="datepicker-2 form-control" name="checkin" placeholder="yyyy-mm-dd" required form-control autocomplete="off">
                                       
                                    </div>
                                    <div class="col-sm-6 my-2">
                                      <label>Check Out</label>
                                      <input type="text" class="datepicker-2 form-control" placeholder="yyyy-mm-dd" name="checkout" required autocomplete="off"> 
                                       
                                    </div>
                                    <div class="col-sm-3 my-2">
                                       <label for="uname"><b>Name</b></label>
                                       </div>
                                       <div class="col-sm-9 my-2">
                                      <input type="text" placeholder="Enter Name" name="name" required class="form-control">
                                    </div>
                                    <div class="col-sm-3 my-2">
                                      <label for="uname"><b>Phone Number</b></label>
                                      </div>
                                       <div class="col-sm-9 my-2">
                                    <input type="text" placeholder="Enter Phone Number" name="nomor" required class="form-control">
                                    </div>
                                    <div class="col-sm-3 my-2">
                                       <label for="psw"><b>Email</b></label>
                                       </div>
                                       <div class="col-sm-9 my-2">
                                       <input type="text" placeholder="Enter Email" name="email" required class="form-control">
                                    </div>
                                    <div class="col-sm-3 my-2">
                                       <label for="psw"><b>Room</b></label>
                                       </div>
                                       <div class="col-sm-9 my-2">
                                       <input type="number" placeholder="Rooms" name="room" required class="form-control" min="0">
                                    </div>
                                    <div class="col-sm-12 my-2">
                                      <a href="statusbarang.php?idbarang=<?= $row["idbarang"]; ?>"></a><button type="submit" name="pesann">Pesan</button></div>
                                    </div>
                                  </form>  
                             </div>
                              
                             
                            </div>

                            <script>
                            // Get the modal
                            var modal = document.getElementById('id01');

                            // When the user clicks anywhere outside of the modal, close it
                            window.onclick = function(event) {
                                if (event.target == modal) {
                                    modal.style.display = "none";
                                }
                            }

                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <hr>
    <?php }; ?>

    </section>
   <footer class="page-footer font-small mdb-color pt-4">

      <center>        
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> Magang IT DEL | BatuHoda Beachs <i class="fa fa-heart-o" aria-hidden="true"></i></a>
        <br>
        <a href="cis.del.ac.id/">
            <strong> Pantai Batuhoda.com</strong>
          </a>
        </center>
     
</footer>
    <!-- Room Section End -->

    <!-- Footer Section Begin -->
    
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>