<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/css.css" rel="stylesheet">
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
</head>
<body>


<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Pesan</button>

<div id="id01" class="modal">
  
    <form class="modal-content animate" action=" " method="post">

      <div class="imgcontainer">
        <h2>Booking Kamar</h2>
        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      </div>
      <div class="container" style="width: 95%" ">
      <div class="form-row align-items-center">
        <div class="col-sm-6 my-2">
          <label>Check In</label>
               <input placeholder="yyyy-mm-dd" type="text" class="form-control datepicker" name="tgl_mulai" required>
           
        </div>
        <div class="col-sm-6 my-2">
           <label>Check Out</label>
               <input placeholder="yyyy-mm-ddr" type="text" class="form-control datepicker" name="tgl_akhir" required>
        </div>
        <div class="col-sm-3 my-2">
           <label for="uname"><b>Name</b></label>
           </div>
           <div class="col-sm-9 my-2">
          <input type="text" placeholder="Enter Name" name="uname" required>
        </div>
        <div class="col-sm-3 my-2">
          <label for="uname"><b>Phone Number</b></label>
          </div>
           <div class="col-sm-9 my-2">
        <input type="text" placeholder="Enter Phone Number" name="pnumber" required>
        </div>
        <div class="col-sm-3 my-2">
           <label for="psw"><b>Email</b></label>
           </div>
           <div class="col-sm-9 my-2">
           <input type="text" placeholder="Enter Email" name="email" required>
        </div>
        <div>
          <div class="col-sm-3 my-2">
             <label for="psw"><b>Room</b></label>
           </div>
           <div class="col-sm-9 my-2">
              <input type="number" class="form-control" placeholder="Room..." name="room" required>
            </div>
        </div>
        <div class="col-sm-12 my-2">
          <button type="submit">Pesan</button>
        </div>
      </form>  
 </div>
  
 
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
 $(function(){
  $(".datepicker").datepicker({
      format: 'yyyy-mm-dd',
      autoclose: true,
      todayHighlight: true,
  });
 });
</script>
</body>
</html>