<?php
  require_once 'functions.php';

  $room = query("SELECT  * FROM categori");
  $waha = query("SELECT * FROM wahana");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  <title>Pantai HD</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">  
  <link rel="stylesheet" type="text/css" href="css/styleMap.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/footer.css">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/popup.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>

<?php
  include 'header.php';
?>

<body>
  <!-- Header -->

<!-- HALAMAN -->
<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/hoda1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
             
        </div>
      </div>
    </div>
    
</div> 
<div class="main-text hidden-xs">
<div class="container-fluid padding">
  <div class="row text-center padding">
    <div class="col-md-4">
      <br>
      <div type="button" class="card" style="background-color: #969494" onclick="document.getElementById('modal-wrapper').style.display='block'">
      <div class="grid1">
        <img src="images/tiket.png"  />
        <p>Ticket</p>
      </div>
      </div>
       <?php

            
       if(isset($_POST["pesan"])) {

                tiket($_POST);
         }
       ?>
       <div id="modal-wrapper" class="modal" >
                <br>
                <br>
            <form class="modal-content animate" action="" method="post" enctype="multipart/form-data">
                  
                  <div class="imgcontainer">
                    <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close PopUp">&times;</span>
                    <img src="img/Logo1.png" style="width: 40%;border-radius: 240px">
                    <h1 style="text-align:center;color: blue">Pemesanan Tiket</h1>
                  </div>

              <div class="container">
                <div class="datepicker">
                  <input type="text" class="datepicker-2" placeholder="Tanggal Kunjungan" name="tanggal" autocomplete="off">
                </div>
                <input type="text" placeholder="Masukkan nama anda" name="nama" autocomplete="off">  
                <input type="text" placeholder="Masukkan Email" name="email">    
                <input type="number" placeholder="Jumlah Tiket" name="jumlah" min="0" autocomplete="off">    
                <input type="text" placeholder="Masukkan Nomor Telepon" name="telpon" autocomplete="off">    
              <button type="submit" name="pesan">Pesan</button>
            </div>
          
        </form>
        
      </div>
    </div>
    <div class="col-md-4">
      <br>
      <div  style="background-color: #969494" class="card">
      <div class="grid1">
        <a href="#room"><img type="button" src="images/home.png"></a>
        <p>Home Stay</p>
      </div>
      </div>
    </div>
    <div class="col-md-4">
      <br>
      <div style="background-color: #969494" class="card">
      <div class="grid1">
        <a href="wahana.php"><img type="button" src="images/bananaboat.png"></a>
        <p>Wahana Air</p>
      </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
</div>

    
</div> 

<div>
  <b><u><p id="tentang" class="text-center" style="font-size: 33px; margin-top: 16px">Tentang</p></u></b>
</div>

<div class="container-fluid">
<div class="row">
  <div class="col-md-6">
    <div id="map-container-google-1" class="z-depth-1-half map-container" style="width: 100%; ">
      <iframe src="https://maps.google.com/maps?q=Batuhoda Beach&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>  
  </div>
    <div class="col-md-6">
      <h3 style="margin-top: 20px;"><b>Batu Hoda Beach</b></h3>
      
      <p align="justify">Pantai pasir putih Samosir, Batu Hoda atau dikenal dengan nama Batuhoda Beach akan menjadi destinasi pantai pertama di Danau Toba. Meski sudah banyak warga dan turis yang berkunjung ke tempat wisata Danau Toba ini, pantai pasir putih Samosir Batu Hoda baru diluncurkan pada awal September ini.</p>
      <p align="justify">Selain pemandangan alam yang ciamik, destinasi Pantai Batu Hoda Samosir ini pun tak lepas dari pengaruh tren wisata kekinian. Pantai di pinggiran Danau Toba ini dilengkapi dengan berbagai spot foto artsy. Salah satunya, rumah berbentuk rumah burung hantu atau pun rumah kayu yang ada di pinggir pantai, seperti di Pantai Brighton di Melbourne, Australia.</p>

      <center><input type="button" onclick="window.open('https://phinemo.com/pantai-batu-hoda-samosir-di-danau-toba/')"  class="btn btn-dark" name="others" value="View More.." style="width :300px;"> </center>
    </div>  
  </div>
</div>


<div style="background-color: black; margin-top: 80px;">
  <div>
    <b><u><p id= "fasilitas" class="text-center" style="font-size: 33px; padding-top: 20px ; margin-top: 30px; color: white;">Wahana Air</p></u></b>
  </div>

  <center>
  <div class="row">
    <?php foreach ($waha as $row) :?>
    <div class="col-md-3">
      <div class="card" style="width: 18rem;">
       <img src="images/<?php echo $row["foto"] ?>" class="bd-placeholder-img card-img-top" width="100%" height="180" preserveAspectRatio="xMidYMid slice" role="img"><rect width="100%" height="100%" fill="#868e96"/>
       <div class="card-body">
         <h5 class="card-title"> <?php  echo $row["nama"] ?> </h5>
        <p class="card-text">Rp <?php echo $row["harga"] ?>/Trip</p>
      </div>
     </div>
    </div>
    <?php endforeach ; ?>
  </div>
    </center>



    <br>
    <br>
        <center><a href="wahana.php" class="btn btn-primary" style="background-color: #FFD700; color: black; width: 250px; height:40px;"><b> View More</b></a></center>
    <br>

  <div id="room">
    <b><u><p class="text-center"  style="font-size: 33px; padding-top: 20px ; margin-top: 30px; color: white;">amaRis Home Stay</p></u></b>
  </div>  
    <center>
  <div class="row" >
    <?php foreach ($room as $row) :?>
    <div class="col-md-3">
      <div class="card" style="width: 18rem;">
       <img src="img/rooms/<?php echo $row["foto"] ?>" class="bd-placeholder-img card-img-top" width="100%" height="180" preserveAspectRatio="xMidYMid slice" role="img"><rect width="100%" height="100%" fill="#868e96"/>
       <div class="card-body">
         <h5 class="card-title"><?php  if($row["id_categori"] == 1){
                                    echo "Standard Room";
                                }elseif ($row["id_categori"] == 2) {
                                    echo "Family Room";
                                }else{
                                    echo "Villa";
                                } ?> </h5>
        <p class="card-text">Rp <?php echo $row["harga"] ?>/Room</p>
        <a href="rooms.php?idkategori=<?= $row["id_categori"]; ?>" class="btn btn-primary" style="background-color:#FFD700; color: black;">Pesan</a>
      </div>
     </div>
    </div>

    <?php endforeach ; ?>

     
     <div class="col-md-3">
      <div class="card" style="width: 18rem;">
       <img src="images/galartikar.jpg" class="bd-placeholder-img card-img-top" width="100%" height="180" preserveAspectRatio="xMidYMid slice" role="img"><rect width="100%" height="100%" fill="#868e96"/>

       <div class="card-body">
         <h5 class="card-title">Gelar Tikar</h5>
        <p class="card-text">Rp 30.000/Orang untuk 1 malam</p>
        <!-- <a href="#" class="btn btn-primary" style="background-color:#FFD700; color: black;">Pesan</a> -->
        <br>
      </div>
     </div>
    </div>
    </center>

    <br>
       <!--  <center><a href="rooms.php" class="btn btn-primary" style="background-color: #FFD700; color: black; width: 250px; height:40px;"><b> View More</b></a></center>
    <br> -->
</div>





<?php
    include 'footer.php';
?>




<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
 <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js'></script>
</body>
</html>

