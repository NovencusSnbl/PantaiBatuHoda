<link rel="stylesheet" type="text/css" href="css/footer.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">


<footer id="sticky-footer" >

  <!-- Footer Links -->
  <div class="container text-center text-md-left">
    <div>
    <b><u><p id= "hubungi" class="text-center" style="font-size: 33px; padding-top: 20px ; margin-top: 30px; color: black;">Hubungi Kami</p></u></b>
  </div>  

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Content -->
        <h5 class="font-weight-bold text-uppercase mb-4">Batu Hoda Beach</h5>
        <p class="col-md-12">
		    <div id="map-container-google-1" style="width: 120%; ">
		      <iframe src="https://maps.google.com/maps?q=Batuhoda Beach&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" style="border:0" allowfullscreen></iframe>
		    </div>  
		  </p>

      </div>
      <!-- Grid column -->

     
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="font-weight-bold text-uppercase mb-4">Location</h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <i class="fas fa-home mr-3 text"></i>Simanindo, Samosir, Sumatera Utara 22395</p>
          </li>
          <li>
            <p>
              <i class="fas fa-envelope mr-3"></i> batuhodabeach@gmail.com</p>
          </li>
          <li>
            <p>
              <i class="fas fa-phone mr-3"></i> + 62 812 6390 7080</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

        <!-- Social buttons -->
        <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>

        <!-- Facebook -->

        <a type="button" class="btn-floating btn-fb white-text mr-md-6 mr-4 fa-2x" href="https://www.facebook.com/batuhodabeach.samosir">
          <i class="fab fa-facebook-f fa-lg"></i>
        </a>
        <!-- Twitter -->
        <a type="button" class="btn-floating btn-tw white-text mr-md-6 mr-4 fa-2x hre" href="https://www.instagram.com/batuhodabeachofficial/">
          <i class="fab fa-instagram fa-lg"></i>
        </a>


      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->
  <div id="copy" class="bg-#000000 text-center text-white"> Magang IT DEL | BatuHoda Beachs<br>
    <a class="text-white" href="https://csi.del.ac.id/"> Pantai Batuhoda.com</a>
  </div>

</footer>